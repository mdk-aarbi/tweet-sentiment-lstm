TweetEval sentiment splits (cardiffnlp/tweet_eval, config sentiment). Labels: 0 negative, 1 neutral, 2 positive.
Original source: https://huggingface.co/datasets/cardiffnlp/tweet_eval
Citation: Barbieri et al. 2020, TweetEval, Findings of EMNLP. Based on SemEval-2017 Task 4 (Rosenthal et al., 2017).
Not collected by the project author; included here so the project can be reproduced.
